import "./globals.css";
import { Providers } from "./providers.js";

export const metadata = {
  title: "Patrol/Ticket Ops",
  description: "Dashboard pro patroly a tickety",
};

export default function RootLayout({ children }) {
  return (
    <html lang="cs">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
