import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "../lib/auth.js";
import SignInButton from "./sign-in-button.js";

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  if (session) redirect("/dashboard");

  return (
    <div className="shell center-screen">
      <div className="brand" style={{ fontSize: 22 }}>
        <span className="dot" />
        Patrol / Ticket Ops
      </div>
      <p style={{ color: "var(--text-dim)", maxWidth: 380 }}>
        Přehled běžících a uzavřených patrol, měsíčních uzávěrek a ticketů.
        Přihlas se přes Discord účtem, který má přístup na server.
      </p>
      <SignInButton />
    </div>
  );
}
