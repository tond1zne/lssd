import { verifyDiscordRequest } from "../../../../lib/verify.js";
import {
  handleZahajitPatrolu,
  handlePatrolEndButton,
  handlePatrolAddSupButton,
  handlePatrolAddSupSelect,
} from "../../../../lib/commands/patrol.js";
import { handleUzavritMesic } from "../../../../lib/commands/uzavritmesic.js";
import {
  handleTicketPanelCommand,
  handleTicketCreateButton,
  handleTicketCloseButton,
} from "../../../../lib/commands/ticket.js";

export async function POST(req) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-signature-ed25519");
  const timestamp = req.headers.get("x-signature-timestamp");

  if (!verifyDiscordRequest(rawBody, signature, timestamp)) {
    return new Response("invalid request signature", { status: 401 });
  }

  const interaction = JSON.parse(rawBody);

  // PING - Discord si tímhle ověřuje endpoint při nastavování URL
  if (interaction.type === 1) {
    return Response.json({ type: 1 });
  }

  // Slash příkazy
  if (interaction.type === 2) {
    const name = interaction.data.name;

    if (name === "zahajitpatrolu") {
      const result = await handleZahajitPatrolu(interaction);
      return Response.json(result);
    }

    if (name === "uzavritmesic") {
      const result = await handleUzavritMesic(interaction);
      return Response.json(result);
    }

    if (name === "ticket-panel") {
      const result = await handleTicketPanelCommand(interaction);
      return Response.json(result);
    }

    return Response.json({
      type: 4,
      data: { content: "Neznámý příkaz.", flags: 64 },
    });
  }

  // Tlačítka a select menu
  if (interaction.type === 3) {
    const customId = interaction.data.custom_id;

    if (customId.startsWith("patrol_end:")) {
      const patrolId = customId.split(":")[1];
      const result = await handlePatrolEndButton(interaction, patrolId);
      return Response.json(result);
    }

    if (customId.startsWith("patrol_addsup_select:")) {
      const patrolId = customId.split(":")[1];
      const result = await handlePatrolAddSupSelect(interaction, patrolId);
      return Response.json(result);
    }

    if (customId.startsWith("patrol_addsup:")) {
      const patrolId = customId.split(":")[1];
      const result = await handlePatrolAddSupButton(interaction, patrolId);
      return Response.json(result);
    }

    if (customId === "ticket_create") {
      const result = await handleTicketCreateButton(interaction);
      return Response.json(result);
    }

    if (customId === "ticket_close") {
      const result = await handleTicketCloseButton(interaction);
      return Response.json(result);
    }
  }

  return Response.json({
    type: 4,
    data: { content: "Nepodporovaná interakce.", flags: 64 },
  });
}
