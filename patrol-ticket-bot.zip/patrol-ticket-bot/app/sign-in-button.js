"use client";

import { signIn } from "next-auth/react";

export default function SignInButton() {
  return (
    <button className="btn" onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}>
      Přihlásit se přes Discord
    </button>
  );
}
