import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "../../lib/auth.js";
import { checkDashboardAccess } from "../../lib/accessControl.js";

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/");

  const access = await checkDashboardAccess(session.user.id);
  if (!access.allowed) {
    return (
      <div className="shell center-screen">
        <div className="brand" style={{ fontSize: 20 }}>
          <span className="dot" style={{ background: "var(--red)" }} />
          Přístup odepřen
        </div>
        <p style={{ color: "var(--text-dim)" }}>
          Účet <b>{session.user.username}</b> nemá na serveru roli pro přístup do dashboardu.
        </p>
      </div>
    );
  }

  return (
    <div className="shell">
      <div className="brand">
        <span className="dot" />
        Patrol / Ticket Ops
      </div>
      <nav className="nav">
        <a href="/dashboard">Přehled</a>
        <a href="/dashboard/patrols">Patroly</a>
        <a href="/dashboard/tickets">Tickety</a>
      </nav>
      {children}
    </div>
  );
}
