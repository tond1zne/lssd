import { query } from "../../../lib/db.js";

export const dynamic = "force-dynamic";

export default async function TicketsPage() {
  const guildId = process.env.DISCORD_GUILD_ID;
  const { rows } = await query(
    `select * from tickets where guild_id=$1 order by created_at desc limit 100`,
    [guildId]
  );

  return (
    <>
      <div className="section-title">Tickety (posledních 100)</div>
      {rows.length === 0 ? (
        <div className="empty">Zatím žádný ticket.</div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Stav</th>
              <th>Uživatel</th>
              <th>Vytvořen</th>
              <th>Uzavřen</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>
                  <span className={`badge ${t.status === "open" ? "open" : "closed"}`}>
                    {t.status === "open" ? "otevřený" : "uzavřený"}
                  </span>
                </td>
                <td>{t.username}</td>
                <td className="mono">{new Date(t.created_at).toLocaleString("cs-CZ")}</td>
                <td className="mono">
                  {t.closed_at ? new Date(t.closed_at).toLocaleString("cs-CZ") : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
