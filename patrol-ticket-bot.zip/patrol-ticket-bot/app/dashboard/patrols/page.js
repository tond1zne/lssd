import { query } from "../../../lib/db.js";
import { formatDuration } from "../../../lib/format.js";

export const dynamic = "force-dynamic";

export default async function PatrolsPage() {
  const guildId = process.env.DISCORD_GUILD_ID;
  const { rows } = await query(
    `select * from patrols where guild_id=$1 order by started_at desc limit 100`,
    [guildId]
  );

  return (
    <>
      <div className="section-title">Patroly (posledních 100)</div>
      {rows.length === 0 ? (
        <div className="empty">Zatím žádná patrola.</div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Stav</th>
              <th>Uživatel</th>
              <th>Supervisor</th>
              <th>Začátek</th>
              <th>Délka</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id}>
                <td>
                  <span className={`badge ${p.status === "active" ? "active" : "closed"}`}>
                    {p.status === "active" ? "probíhá" : "hotovo"}
                  </span>
                </td>
                <td>{p.username}</td>
                <td>{p.supervisor_username || "—"}</td>
                <td className="mono">{new Date(p.started_at).toLocaleString("cs-CZ")}</td>
                <td className="mono">
                  {p.duration_seconds != null ? formatDuration(p.duration_seconds) : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
