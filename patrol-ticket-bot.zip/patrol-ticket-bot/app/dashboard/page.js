import { query } from "../../lib/db.js";
import { formatDuration } from "../../lib/format.js";

export const dynamic = "force-dynamic";

export default async function DashboardHome() {
  const guildId = process.env.DISCORD_GUILD_ID;

  const [{ rows: periodRows }, { rows: activeRows }, { rows: openTicketRows }, { rows: reportRows }] =
    await Promise.all([
      query(
        `select coalesce(sum(duration_seconds),0) as total, count(*) as cnt
         from patrols where guild_id=$1 and archived=false and status='closed'`,
        [guildId]
      ),
      query(`select count(*) as cnt from patrols where guild_id=$1 and status='active'`, [guildId]),
      query(`select count(*) as cnt from tickets where guild_id=$1 and status='open'`, [guildId]),
      query(
        `select * from monthly_reports where guild_id=$1 order by created_at desc limit 5`,
        [guildId]
      ),
    ]);

  const periodTotal = Number(periodRows[0].total);
  const periodCount = Number(periodRows[0].cnt);
  const activeCount = Number(activeRows[0].cnt);
  const openTickets = Number(openTicketRows[0].cnt);

  return (
    <>
      <div className="grid">
        <div className="stat">
          <div className="label">Aktuální období — čas</div>
          <div className="value amber mono">{formatDuration(periodTotal)}</div>
        </div>
        <div className="stat">
          <div className="label">Aktuální období — patroly</div>
          <div className="value mono">{periodCount}</div>
        </div>
        <div className="stat">
          <div className="label">Právě probíhá</div>
          <div className="value mono">{activeCount}</div>
        </div>
        <div className="stat">
          <div className="label">Otevřené tickety</div>
          <div className="value teal mono">{openTickets}</div>
        </div>
      </div>

      <div className="section-title">Historie uzávěrek</div>
      {reportRows.length === 0 ? (
        <div className="empty">Zatím žádná uzávěrka (/uzavritmesic).</div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Období</th>
              <th>Patroly</th>
              <th>Celkový čas</th>
              <th>Uzavřel</th>
              <th>Kdy</th>
            </tr>
          </thead>
          <tbody>
            {reportRows.map((r) => (
              <tr key={r.id}>
                <td>{r.period_label}</td>
                <td className="mono">{r.patrol_count}</td>
                <td className="mono">{formatDuration(r.total_seconds)}</td>
                <td>{r.closed_by_username}</td>
                <td className="mono">{new Date(r.created_at).toLocaleString("cs-CZ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
