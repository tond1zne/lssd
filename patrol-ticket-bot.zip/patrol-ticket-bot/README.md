# Patrol / Ticket bot + dashboard

Discord bot bez vlastního serveru (běží jako HTTP interactions endpoint na
Vercelu zdarma) + webový dashboard pro správu a přehled.

## Jak to funguje

Klasický bot přes `discord.js` potřebuje běžet 24/7 a držet websocket
spojení – to na Vercelu zdarma nejde. Tenhle bot místo toho používá
**Discord Interactions Endpoint**: Discord posílá slash příkazy a kliky na
tlačítka jako obyčejný HTTPS POST požadavek na `/api/discord/interactions`.
To na serverless platformě funguje bez problému. Data (běžící patroly,
uzávěrky, tickety) se ukládají do Neon Postgres databáze, protože si mezi
jednotlivými požadavky nic nepamatuje sama Vercel funkce.

## 1) Založ Discord aplikaci

1. https://discord.com/developers/applications → **New Application**
2. Záložka **General Information** → zkopíruj **Public Key** → `DISCORD_PUBLIC_KEY`,
   **Application ID** → `DISCORD_APP_ID`
3. Záložka **Bot** → **Reset Token** → zkopíruj → `DISCORD_BOT_TOKEN`
   (vypni "Public Bot", pokud má být jen na tvém serveru)
4. Záložka **OAuth2** → zkopíruj **Client ID** → `DISCORD_CLIENT_ID` a
   **Client Secret** → `DISCORD_CLIENT_SECRET`
5. Pozvi bota na server: v **OAuth2 → URL Generator** zaškrtni scope `bot`
   a `applications.commands`, u bot permissions zaškrtni aspoň
   `Manage Channels`, `Send Messages`, `Embed Links`, `View Channels`.
   Otevři vygenerovaný odkaz a přidej bota na server.
6. Zjisti `DISCORD_GUILD_ID` (na Discordu zapni Developer Mode v nastavení
   → pravé tlačítko na server → Copy Server ID).

## 2) Založ databázi (Neon)

1. https://neon.tech → nový projekt (free tier stačí)
2. Zkopíruj connection string → `DATABASE_URL`
   (funguje i přes Vercel: Vercel dashboard → Storage → Connect Database → Neon,
   propojí se to automaticky a proměnnou ti tam vyplní samo)
3. V Neon SQL editoru spusť obsah `sql/schema.sql` (vytvoří potřebné tabulky)

## 3) Nasazení na Vercel

1. Nahraj tenhle projekt do GitHub repa
2. Na https://vercel.com → **New Project** → naimportuj repo
3. V **Environment Variables** vyplň vše z `.env.example`:
   - `DISCORD_APP_ID`, `DISCORD_PUBLIC_KEY`, `DISCORD_BOT_TOKEN`, `DISCORD_GUILD_ID`
   - `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`
   - `DATABASE_URL`
   - `NEXTAUTH_SECRET` (vygeneruj třeba přes `openssl rand -base64 32`)
   - `NEXTAUTH_URL` = přesná URL tvého nasazení, např. `https://tvuj-bot.vercel.app`
   - volitelně role: `ROLE_ID_SUPERVISOR`, `ROLE_ID_UZAVRIT_MESIC`, `ROLE_ID_SUPPORT`,
     `ROLE_ID_DASHBOARD_ACCESS`, `TICKET_CATEGORY_ID`
4. Deploy.
5. V Discord Developer Portal → **General Information** → **Interactions
   Endpoint URL** vyplň `https://tvuj-bot.vercel.app/api/discord/interactions`
   a ulož (Discord si endpoint hned ověří přes PING, takže musí být už nasazený).
6. V Discord OAuth2 nastavení přidej redirect URL:
   `https://tvuj-bot.vercel.app/api/auth/callback/discord`

## 4) Zaregistruj slash příkazy

Lokálně (jednou, případně znovu po každé úpravě příkazů):

```bash
export DISCORD_APP_ID=...
export DISCORD_GUILD_ID=...
export DISCORD_BOT_TOKEN=...
npm install
npm run register-commands
```

Zaregistrují se: `/zahajitpatrolu`, `/uzavritmesic`, `/ticket-panel`.

`/uzavritmesic` a `/ticket-panel` jsou defaultně omezené na roli s
oprávněním **Manage Server**. Přesnou roli, která je smí použít, si můžeš
upřesnit v **Server Settings → Integrations → [jméno bota] → příkazy**.

## 5) Použití

- **`/ticket-panel`** (kdekoliv, kde chceš mít podporu) – pošle embed s
  tlačítkem "Vytvořit ticket". Klik vytvoří privátní kanál pro daného
  uživatele (+ roli podpory, pokud je nastavená `ROLE_ID_SUPPORT`) s
  tlačítkem "Zavřít ticket".
- **`/zahajitpatrolu`** – pošle embed se stavem "Probíhá" a dvěma tlačítky:
  - **Ukončit patrolu** – spočítá délku, embed se přepíše na finální stav
    (délka téhle patroly + součet za celé aktuální období).
  - **Přidat supervisora** – ephemeral výběr uživatele, po vybrání se
    doplní do embedu.
- **`/uzavritmesic`** – vypíše celkový čas a počet patrol od poslední
  uzávěrky, uloží to jako záznam a vynuluje počítadlo (staré patroly zůstanou
  v historii, jen se označí jako "archivované" a dál se nezapočítávají).

## 6) Dashboard

Na `https://tvuj-bot.vercel.app` se přihlásíš přes Discord (tlačítko na
úvodní stránce). Přístup do dashboardu má jen ten, kdo má na serveru roli
nastavenou v `ROLE_ID_DASHBOARD_ACCESS` (pokud proměnnou necháš prázdnou,
dashboard uvidí kdokoliv na serveru, kdo se přihlásí). Uvidíš:

- **Přehled** – aktuální nasčítaný čas za probíhající období, kolik patrol
  právě běží, kolik je otevřených ticketů, historii uzávěrek
- **Patroly** – posledních 100 patrol se stavem a délkou
- **Tickety** – posledních 100 ticketů se stavem

Dashboard je zatím jen ke čtení (bez mazání/editace) – dej vědět, pokud
chceš přidat i akce (např. ruční uzavření patroly z webu), doplním to.

## Struktura projektu

```
app/
  api/discord/interactions/route.js   <- webhook, sem chodí všechny sl. příkazy a tlačítka
  api/auth/[...nextauth]/route.js     <- přihlášení do dashboardu
  dashboard/                          <- webové stránky dashboardu
lib/
  commands/patrol.js                  <- logika /zahajitpatrolu + tlačítka
  commands/ticket.js                  <- logika ticketů
  commands/uzavritmesic.js            <- logika uzávěrky
  db.js, discordApi.js, verify.js     <- pomocné funkce
scripts/register-commands.mjs         <- jednorázová registrace příkazů
sql/schema.sql                        <- databázové tabulky
```

## Poznámky / co si pohlídat

- Vercel free plán má limit na dobu běhu jedné funkce (10s) – všechny
  handlery jsou navržené tak, aby se do toho pohodlně vešly.
- `duration_seconds` a časy se počítají na serveru, ne v Discord klientovi,
  takže jsou přesné bez ohledu na to, kdo má jaké časové pásmo.
- Pokud budeš chtít historii ticketů/patrol i po smazání kanálu, nic se
  nemaže automaticky – zavřený ticket kanál zůstává (jen uzavřenému
  uživateli zmizí právo psát). Smazání kanálů si můžeš přidat zvlášť, pokud
  chceš.
