-- Spusť tohle jednou v Neon SQL editoru (Neon dashboard -> SQL Editor), než bota poprvé nasadíš.

create table if not exists patrols (
  id serial primary key,
  guild_id text not null,
  channel_id text not null,
  message_id text not null,
  user_id text not null,
  username text not null,
  supervisor_id text,
  supervisor_username text,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  duration_seconds integer,
  status text not null default 'active', -- 'active' | 'closed'
  archived boolean not null default false
);

create table if not exists monthly_reports (
  id serial primary key,
  guild_id text not null,
  closed_by_id text not null,
  closed_by_username text not null,
  total_seconds integer not null,
  patrol_count integer not null,
  period_label text not null,
  created_at timestamptz not null default now()
);

create table if not exists tickets (
  id serial primary key,
  guild_id text not null,
  channel_id text not null unique,
  user_id text not null,
  username text not null,
  status text not null default 'open', -- 'open' | 'closed'
  claimed_by_id text,
  claimed_by_username text,
  created_at timestamptz not null default now(),
  closed_at timestamptz,
  closed_by_id text
);

create index if not exists idx_patrols_guild_status on patrols (guild_id, status, archived);
create index if not exists idx_tickets_guild_status on tickets (guild_id, status);
