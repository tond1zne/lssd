// Spustit lokálně (jednou, nebo po každé změně příkazů):
//   node scripts/register-commands.mjs
// Potřebuje v prostředí DISCORD_APP_ID, DISCORD_BOT_TOKEN, DISCORD_GUILD_ID
// (buď je vyexportuj, nebo si nainstaluj balíček `dotenv` a načti .env).

const appId = process.env.DISCORD_APP_ID;
const guildId = process.env.DISCORD_GUILD_ID;
const token = process.env.DISCORD_BOT_TOKEN;

if (!appId || !guildId || !token) {
  console.error(
    "Chybí DISCORD_APP_ID / DISCORD_GUILD_ID / DISCORD_BOT_TOKEN v prostředí."
  );
  process.exit(1);
}

// 32 = MANAGE_GUILD permission bit - jen lidi/role s tímhle oprávněním uvidí příkaz.
// Konkrétní roli, která smí /uzavritmesic použít, si pak nastavíš v Discordu:
// Server Settings -> Integrations -> tvůj bot -> najdi příkaz -> přidej roli.
const MANAGE_GUILD = "32";

const commands = [
  {
    name: "zahajitpatrolu",
    description: "Zahájí novou patrolu a spustí měření času.",
    type: 1,
  },
  {
    name: "uzavritmesic",
    description: "Uzavře aktuální období, ukáže celkový čas a vynuluje počítadlo.",
    type: 1,
    default_member_permissions: MANAGE_GUILD,
  },
  {
    name: "ticket-panel",
    description: "Pošle do tohoto kanálu panel pro vytváření ticketů.",
    type: 1,
    default_member_permissions: MANAGE_GUILD,
  },
];

const res = await fetch(
  `https://discord.com/api/v10/applications/${appId}/guilds/${guildId}/commands`,
  {
    method: "PUT",
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(commands),
  }
);

if (!res.ok) {
  console.error("Registrace selhala:", res.status, await res.text());
  process.exit(1);
}

console.log("Příkazy zaregistrovány ✅");
console.log(await res.json());
